#ifndef RENDERING_H_
#define RENDERING_H_

void render_game(SDL_Renderer *renderer, const game_t *game);

#endif  // RENDERING_H_