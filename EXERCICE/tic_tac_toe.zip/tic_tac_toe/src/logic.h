#ifndef LOGIC_H_
#define LOGIC_H_

void click_on_cell(game_t *game, int row, int column);

#endif  // LOGIC_H_